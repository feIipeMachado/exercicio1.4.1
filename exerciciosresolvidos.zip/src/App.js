const Filme = ({ nome, diretores }) => {
  return (
    <div>
      <h4>{nome}</h4>
      <ul>
        {diretores.map((diretor) => (
          <li>{diretor}</li>
        ))}
      </ul>
    </div>
  );
};

const GanhadoresOscar = ({ nomes }) => {
  return (
    <div>
      <h2>{nomes}</h2>
      <ul>
        <li>Ganhou Oscar!</li>
      </ul>
    </div>
  );
};

const SenhorDosAneis = ({ nomes }) => {
  return (
    <div>
      <h1>{nomes}</h1>
      <ul>
        <li>🏆</li>
      </ul>
    </div>
  );
};

const filmes = [
  {
    nome: "O Senhor do Aneis: A Sociedade do Anel",
    lancamento: 2002,
    oscar: true,
    diretores: ["Peter Jackson"],
    generos: ["Fantasia", "Aventura"]
  },
  {
    nome: "Harry Potter e a Pedra Filosofal",
    lancamento: 2001,
    oscar: false,
    diretores: ["Chris Columbus"],
    generos: ["Fantasia"]
  },
  {
    nome: "Matrix",
    oscar: true,
    lancamento: 1999,
    diretores: ["Lana Wachowski", "Lilly Wachowski"],
    generos: ["Ação", "Ficção Cientifica"]
  },
  {
    nome: "Meninas Malvadas",
    oscar: false,
    lancamento: 2004,
    diretores: ["Mark Waters"],
    generos: ["Comédia"]
  }
];

const senhorDosAneis = filmes.filter((filme) => filme.lancamento === 2002);

const ganhadoresOscar = filmes.filter((filme) => filme.oscar === true);

function App() {
  return (
    <div>
      {filmes.map((filme) => (
        <Filme nome={filme.nome} diretores={filme.diretores} />
      ))}
      {ganhadoresOscar.map((ganhadorOscar) => (
        <GanhadoresOscar nomes={ganhadorOscar.nome} />
      ))}
      {senhorDosAneis.map((senhorDoAnel) => (
        <SenhorDosAneis nomes={senhorDoAnel.nome} />
      ))}
    </div>
  );
}

export default App;
